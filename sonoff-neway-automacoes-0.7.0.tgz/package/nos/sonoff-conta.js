const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const api = require('./sonoff-api');

module.exports = function (RED) {
    function arquivoDe(id) {
        return path.join(RED.settings.userDir || '.', 'sonoff_dispositivos_' + id + '.json');
    }

    function lerManuais(texto) {
        const lista = [];
        for (const linha of String(texto || '').split(/\r?\n/)) {
            const t = linha.trim();
            if (!t) continue;
            const p = t.split(/[;,\s]+/);
            const ip = p.find((x) => /^\d+\.\d+\.\d+\.\d+(:\d+)?$/.test(x)) || '';
            const resto = p.filter((x) => x !== ip);
            const m = /^(.+):(\d+)$/.exec(ip);
            lista.push({
                id: resto[0],
                chave: resto[1] || '',
                ip: m ? m[1] : ip,
                porta: m ? Number(m[2]) : 8081,
                nome: resto[0]
            });
        }
        return lista.filter((x) => x.id);
    }

    function SonoffConta(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.eventos = new EventEmitter();
        node.eventos.setMaxListeners(0);
        node.dispositivos = new Map();
        const filas = new Map();
        const consultas = new Map();
        const modo = ['auto', 'local', 'nuvem'].indexOf(config.modo) >= 0 ? config.modo : 'auto';
        const usaLocal = modo !== 'nuvem';
        const usaNuvem = modo !== 'local';
        const intervalo = Math.max(0, Number(config.consulta) || 0);
        let navegador = null;
        let bonjour = null;
        let timer = null;
        let cliente = null;
        let sessao = null;
        let aviso = '';

        function estado(t, c) {
            node.eventos.emit('estado', t, c);
        }

        function obter(id) {
            let d = node.dispositivos.get(id);
            if (!d) {
                d = { id, nome: id, casa: '', chave: '', apikey: '', ip: '', porta: 8081, online: false, noLocal: false, noNuvem: false, status: {}, semChave: false };
                node.dispositivos.set(id, d);
            }
            return d;
        }

        function definirOnline(d, origem, valor) {
            if (origem === 'local') d.noLocal = valor;
            else d.noNuvem = valor;
            const novo = d.noLocal || d.noNuvem;
            if (novo === d.online) return;
            d.online = novo;
            node.eventos.emit('online', d.id, novo);
        }

        function aplicar(id, params, origem) {
            const d = obter(id);
            const novo = api.achatar(params);
            const mudancas = [];
            for (const k of Object.keys(novo)) {
                if (JSON.stringify(d.status[k]) !== JSON.stringify(novo[k])) {
                    d.status[k] = novo[k];
                    mudancas.push({ code: k, value: novo[k] });
                }
            }
            d.semChave = false;
            definirOnline(d, origem, true);
            if (mudancas.length) node.eventos.emit('status', id, mudancas);
        }

        function salvar() {
            const lista = [];
            for (const d of node.dispositivos.values()) {
                if (d.origem === 'nuvem') lista.push({ id: d.id, nome: d.nome, casa: d.casa, chave: d.chave, apikey: d.apikey, modelo: d.modelo, uiid: d.uiid });
            }
            try {
                fs.writeFileSync(arquivoDe(node.id), JSON.stringify({ usuario: config.usuario, sessao, dispositivos: lista }));
            } catch (e) {
                node.warn('nao salvou a lista: ' + e.message);
            }
        }

        function mesclar(lista, origem) {
            for (const x of lista) {
                const d = obter(x.id);
                d.nome = x.nome || d.nome;
                if (x.casa !== undefined) d.casa = x.casa;
                if (x.chave !== undefined && (x.chave || origem === 'nuvem')) d.chave = x.chave;
                if (x.apikey !== undefined) d.apikey = x.apikey;
                if (x.ip) d.ip = x.ip;
                if (x.porta) d.porta = x.porta;
                if (x.modelo !== undefined) d.modelo = x.modelo;
                if (x.uiid !== undefined) d.uiid = x.uiid;
                d.origem = origem;
            }
        }

        function lerCache() {
            try {
                const dado = JSON.parse(fs.readFileSync(arquivoDe(node.id), 'utf8'));
                if (Array.isArray(dado)) {
                    mesclar(dado, 'nuvem');
                } else if (!dado.usuario || dado.usuario === config.usuario) {
                    sessao = dado.sessao || null;
                    mesclar(dado.dispositivos || [], 'nuvem');
                }
            } catch (e) {
                return;
            }
        }

        function resumo() {
            const total = node.dispositivos.size;
            const on = Array.from(node.dispositivos.values()).filter((d) => d.online).length;
            const texto = on + '/' + total + ' online' + (aviso ? ' | ' + aviso : '');
            estado(texto, aviso ? 'red' : on ? 'green' : total ? 'yellow' : 'grey');
        }

        function ipDe(servico) {
            const v4 = (servico.addresses || []).find((a) => /^\d+\.\d+\.\d+\.\d+$/.test(a));
            return v4 || (servico.referer && servico.referer.address) || '';
        }

        function aoServico(servico) {
            const nome = String(servico.name || '');
            if (!/^ewelink/i.test(nome)) return;
            const id = nome.slice(8, 18);
            if (!/^[0-9a-zA-Z]{10}$/.test(id)) return;
            const novoDisp = !node.dispositivos.has(id);
            const d = obter(id);
            const ip = ipDe(servico);
            if (ip) d.ip = ip;
            if (servico.port) d.porta = servico.port;
            let params;
            try {
                params = api.interpretarTxt(servico.txt || {}, d.chave);
            } catch (e) {
                d.semChave = true;
                resumo();
                return;
            }
            if (params && params.semChave) {
                d.semChave = true;
                resumo();
                return;
            }
            if (params) aplicar(id, params, 'local');
            resumo();
            if (novoDisp) node.eventos.emit('dispositivos');
        }

        function aoCair(servico) {
            const d = node.dispositivos.get(String(servico.name || '').slice(8, 18));
            if (!d) return;
            definirOnline(d, 'local', false);
            resumo();
        }

        function iniciarMdns() {
            try {
                const { Bonjour } = require('bonjour-service');
                bonjour = new Bonjour();
                navegador = bonjour.find({ type: 'ewelink', protocol: 'tcp' });
                navegador.on('up', aoServico);
                navegador.on('txt-update', aoServico);
                navegador.on('down', aoCair);
            } catch (e) {
                node.warn('mDNS indisponivel: ' + e.message);
            }
        }

        function iniciarNuvem() {
            if (cliente) cliente.parar();
            cliente = new api.ClienteNuvem(sessao, api.appId());
            cliente.on('update', (id, params) => {
                if (node.dispositivos.has(id)) aplicar(id, params, 'nuvem');
            });
            cliente.on('online', (id, valor) => {
                const d = node.dispositivos.get(id);
                if (!d) return;
                definirOnline(d, 'nuvem', valor);
                resumo();
            });
            cliente.on('conectado', () => {
                aviso = '';
                resumo();
            });
            cliente.on('erro', (msg) => {
                aviso = 'nuvem: ' + String(msg).slice(0, 40);
                resumo();
            });
            cliente.iniciar();
        }

        async function carregarNuvem(forcar) {
            const c = node.credentials || {};
            const temLogin = !!(config.usuario && c.senha);
            let lista = null;
            if (!forcar && sessao) {
                try {
                    lista = await api.listarNuvem(sessao);
                } catch (e) {
                    if (!temLogin) throw e;
                }
            }
            if (!lista) {
                if (!temLogin) return false;
                estado('entrando na nuvem', 'yellow');
                sessao = await api.entrar({ usuario: config.usuario, senha: c.senha, pais: config.pais });
                lista = await api.listarNuvem(sessao);
            }
            mesclar(lista, 'nuvem');
            if (usaNuvem) {
                for (const x of lista) {
                    const d = node.dispositivos.get(x.id);
                    definirOnline(d, 'nuvem', x.online);
                    if (x.params && Object.keys(x.params).length) aplicar(x.id, x.params, 'nuvem');
                    if (!x.online) definirOnline(d, 'nuvem', false);
                }
            }
            salvar();
            if (usaNuvem) iniciarNuvem();
            return true;
        }

        async function consultar(id) {
            const d = node.dispositivos.get(id);
            if (!d) return false;
            if (usaLocal && d.ip) {
                try {
                    const r = await api.enviarLocal(d, 'info', {});
                    if (r.erro === 0 && r.dados && typeof r.dados === 'object') {
                        aplicar(id, r.dados, 'local');
                        return true;
                    }
                } catch (e) {
                    definirOnline(d, 'local', false);
                }
            }
            if (usaNuvem && cliente && cliente.consultar(d)) {
                await new Promise((ok) => setTimeout(ok, 1200));
                return d.online;
            }
            return false;
        }
        node.consultar = consultar;

        function consultarLocais() {
            for (const d of node.dispositivos.values()) {
                if (d.ip) consultar(d.id).then(resumo);
            }
        }

        node.comando = function (id, comandos) {
            const d = node.dispositivos.get(id);
            if (!d) return Promise.reject(new Error('dispositivo desconhecido'));
            const anterior = filas.get(id) || Promise.resolve();
            const trabalho = anterior.catch(() => {}).then(async () => {
                for (const c of comandos) {
                    const bruto = c.zeroconf || api.montarComando(c.code, c.value);
                    let feito = false;
                    let falhaLocal = null;
                    if (usaLocal && d.ip) {
                        try {
                            const r = await api.enviarLocal(d, bruto.comando, bruto.dados);
                            if (r.erro !== 0) throw new Error('erro ' + r.erro);
                            feito = true;
                        } catch (e) {
                            falhaLocal = e;
                        }
                    }
                    if (!feito) {
                        if (!usaNuvem || !sessao) throw falhaLocal || new Error('sem IP (aguarde o mDNS)');
                        await api.enviarNuvem(sessao, d, bruto.dados);
                    }
                }
                clearTimeout(consultas.get(id));
                consultas.set(id, setTimeout(() => consultar(id), 700));
                return 'ok';
            });
            filas.set(id, trabalho);
            return trabalho;
        };

        node.atualizarNuvem = async function () {
            const ok = await carregarNuvem(true);
            mesclar(lerManuais(config.manuais), 'manual');
            resumo();
            node.eventos.emit('dispositivos');
            return ok;
        };

        async function iniciar() {
            lerCache();
            mesclar(lerManuais(config.manuais), 'manual');
            resumo();
            if (usaLocal) {
                iniciarMdns();
                if (intervalo) timer = setInterval(consultarLocais, intervalo * 1000);
                consultarLocais();
            }
            node.eventos.emit('dispositivos');
            try {
                if (await carregarNuvem(false)) {
                    mesclar(lerManuais(config.manuais), 'manual');
                    resumo();
                    node.eventos.emit('dispositivos');
                    if (usaLocal) consultarLocais();
                }
            } catch (e) {
                aviso = 'nuvem: ' + e.message.slice(0, 40);
                resumo();
                node.warn('nuvem: ' + e.message);
            }
        }

        iniciar();

        node.on('close', function (done) {
            if (timer) clearInterval(timer);
            if (cliente) cliente.parar();
            for (const t of consultas.values()) clearTimeout(t);
            try {
                if (navegador) navegador.stop();
                if (bonjour) bonjour.destroy(() => done());
                else done();
            } catch (e) {
                done();
            }
        });
    }

    RED.nodes.registerType('sonoff-conta', SonoffConta, {
        credentials: {
            senha: { type: 'password' }
        }
    });

    RED.httpAdmin.get('/sonoff/:id/dispositivos', RED.auth.needsPermission('flows.read'), (req, res) => {
        const conta = RED.nodes.getNode(req.params.id);
        if (!conta || !conta.dispositivos) {
            res.status(404).json({ erro: 'conta nao implantada' });
            return;
        }
        const lista = Array.from(conta.dispositivos.values()).map((d) => ({
            id: d.id,
            nome: d.nome,
            casa: d.casa,
            ip: d.ip,
            online: d.online,
            semChave: d.semChave,
            codigos: Object.keys(d.status)
        }));
        res.json({ dispositivos: lista });
    });

    RED.httpAdmin.post('/sonoff/:id/atualizar', RED.auth.needsPermission('flows.write'), async (req, res) => {
        const conta = RED.nodes.getNode(req.params.id);
        if (!conta || !conta.atualizarNuvem) {
            res.status(404).json({ erro: 'conta nao implantada' });
            return;
        }
        try {
            const ok = await conta.atualizarNuvem();
            res.json({ ok, total: conta.dispositivos.size });
        } catch (e) {
            res.status(500).json({ erro: e.message });
        }
    });
};
