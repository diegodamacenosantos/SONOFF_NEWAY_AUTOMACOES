module.exports = function (RED) {
    function converter(valor) {
        if (typeof valor === 'string') {
            const t = valor.trim().toLowerCase();
            if (t === 'on' || t === 'true') return true;
            if (t === 'off' || t === 'false') return false;
            if (t !== '' && !isNaN(Number(t))) return Number(t);
        }
        return valor;
    }

    function SonoffDispositivo(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const conta = RED.nodes.getNode(config.conta);
        const codigo = (config.codigo || '').trim();
        const tipo = ['status', 'leitura', 'comando'].indexOf(config.tipo) >= 0 ? config.tipo : 'status';
        const inicial = config.inicial !== false;
        if (!conta) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }
        if (!config.dispositivo) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem dispositivo' });
            return;
        }

        function nomeDe(d) {
            return d ? d.nome : config.dispositivo;
        }

        function etiqueta() {
            const d = conta.dispositivos.get(config.dispositivo);
            if (!d) {
                node.status({ fill: 'grey', shape: 'ring', text: 'aguardando aparelho' });
                return;
            }
            if (d.semChave && !Object.keys(d.status).length) {
                node.status({ fill: 'red', shape: 'ring', text: nomeDe(d) + ' sem chave' });
                return;
            }
            if (!d.online) {
                node.status({ fill: 'red', shape: 'ring', text: nomeDe(d) + ' offline' });
                return;
            }
            let texto;
            if (codigo) {
                texto = codigo + '=' + JSON.stringify(d.status[codigo]);
            } else {
                texto = Object.keys(d.status).length + ' códigos';
            }
            const ligado = codigo && d.status[codigo] === true;
            node.status({ fill: ligado ? 'green' : 'grey', shape: 'dot', text: texto });
        }

        function montarSaida(base, code, value, d) {
            return Object.assign({}, base, {
                payload: value,
                topic: code,
                device: config.dispositivo,
                name: nomeDe(d),
                status: d ? Object.assign({}, d.status) : {}
            });
        }

        function aoStatus(id, mudancas) {
            if (id !== config.dispositivo) return;
            const d = conta.dispositivos.get(id);
            if (tipo === 'status') {
                for (const m of mudancas) {
                    if (codigo && m.code !== codigo) continue;
                    node.send(montarSaida({}, m.code, m.value, d));
                }
            }
            etiqueta();
        }

        function aoOnline(id) {
            if (id === config.dispositivo) etiqueta();
        }

        function aoDispositivos() {
            etiqueta();
            if (tipo !== 'status' || !inicial) return;
            const d = conta.dispositivos.get(config.dispositivo);
            if (!d) return;
            for (const code of Object.keys(d.status)) {
                if (codigo && code !== codigo) continue;
                node.send(montarSaida({}, code, d.status[code], d));
            }
        }

        function montar(msg) {
            if (msg.zeroconf && msg.zeroconf.comando) {
                return [{ zeroconf: { comando: msg.zeroconf.comando, dados: msg.zeroconf.dados || {} } }];
            }
            const p = msg.payload;
            if (p && typeof p === 'object' && !Buffer.isBuffer(p) && !Array.isArray(p)) {
                return Object.keys(p).map((k) => ({ code: k, value: p[k] }));
            }
            const code = codigo || msg.topic;
            if (!code) return null;
            return [{ code: code, value: converter(p) }];
        }

        conta.eventos.on('status', aoStatus);
        conta.eventos.on('online', aoOnline);
        conta.eventos.on('dispositivos', aoDispositivos);
        conta.eventos.on('estado', etiqueta);
        etiqueta();
        if (conta.dispositivos.size) aoDispositivos();

        if (tipo === 'comando') {
            node.on('input', async function (msg, send, done) {
                const comandos = montar(msg);
                if (!comandos || comandos.some((c) => !c.zeroconf && !c.code)) {
                    node.status({ fill: 'red', shape: 'ring', text: 'sem código' });
                    if (done) done('sem código de comando');
                    return;
                }
                try {
                    await conta.comando(config.dispositivo, comandos);
                    node.status({ fill: 'green', shape: 'dot', text: comandos.map((c) => (c.zeroconf ? c.zeroconf.comando : c.code + '=' + JSON.stringify(c.value))).join(' ') });
                    if (done) done();
                } catch (e) {
                    node.status({ fill: 'red', shape: 'ring', text: e.message.slice(0, 40) });
                    if (done) done(e.message);
                }
            });
        }

        if (tipo === 'leitura') {
            node.on('input', async function (msg, send, done) {
                const enviar = send || ((m) => node.send(m));
                await conta.consultar(config.dispositivo);
                const d = conta.dispositivos.get(config.dispositivo);
                if (!d || !d.online) {
                    etiqueta();
                    if (done) done('aparelho offline');
                    return;
                }
                if (codigo && !(codigo in d.status)) {
                    node.status({ fill: 'red', shape: 'ring', text: 'sem código ' + codigo });
                    if (done) done('sem código ' + codigo);
                    return;
                }
                for (const code of codigo ? [codigo] : Object.keys(d.status)) {
                    enviar(montarSaida(msg, code, d.status[code], d));
                }
                etiqueta();
                if (done) done();
            });
        }

        node.on('close', function () {
            conta.eventos.removeListener('status', aoStatus);
            conta.eventos.removeListener('online', aoOnline);
            conta.eventos.removeListener('dispositivos', aoDispositivos);
            conta.eventos.removeListener('estado', etiqueta);
        });
    }

    RED.nodes.registerType('sonoff-dispositivo', SonoffDispositivo);
};
