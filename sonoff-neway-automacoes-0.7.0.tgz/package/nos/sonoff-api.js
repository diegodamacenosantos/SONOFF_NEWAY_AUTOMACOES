const crypto = require('crypto');
const EventEmitter = require('events');
const http = require('http');
const WebSocket = require('ws');

const API = {
    cn: 'https://cn-apia.coolkit.cn',
    as: 'https://as-apia.coolkit.cc',
    us: 'https://us-apia.coolkit.cc',
    eu: 'https://eu-apia.coolkit.cc'
};

const DISPATCH = {
    cn: 'https://cn-dispa.coolkit.cn/dispatch/app',
    as: 'https://as-dispa.coolkit.cc/dispatch/app',
    us: 'https://us-dispa.coolkit.cc/dispatch/app',
    eu: 'https://eu-dispa.coolkit.cc/dispatch/app'
};

const ajustes = { esquemaWs: 'wss' };

function chaveDe(devicekey) {
    return crypto.createHash('md5').update(devicekey, 'utf8').digest();
}

function cifrar(devicekey, objeto) {
    const iv = crypto.randomBytes(16);
    const c = crypto.createCipheriv('aes-128-cbc', chaveDe(devicekey), iv);
    const dados = Buffer.concat([c.update(JSON.stringify(objeto), 'utf8'), c.final()]);
    return { data: dados.toString('base64'), iv: iv.toString('base64') };
}

function decifrar(devicekey, data, iv) {
    const d = crypto.createDecipheriv('aes-128-cbc', chaveDe(devicekey), Buffer.from(iv, 'base64'));
    const bruto = Buffer.concat([d.update(Buffer.from(data, 'base64')), d.final()]).toString('utf8');
    return JSON.parse(bruto.replace(/\x02+$/, ''));
}

function lerTxt(txt) {
    let bruto = '';
    for (let i = 1; i <= 4; i++) {
        const v = txt['data' + i];
        if (v !== undefined) bruto += Buffer.isBuffer(v) ? v.toString('utf8') : String(v);
    }
    return {
        bruto,
        cifrado: String(txt.encrypt) === 'true',
        iv: txt.iv === undefined ? '' : String(txt.iv),
        seq: txt.seq === undefined ? '' : String(txt.seq),
        tipo: txt.type === undefined ? '' : String(txt.type)
    };
}

function interpretarTxt(txt, devicekey) {
    const m = lerTxt(txt);
    if (!m.bruto) return null;
    if (m.cifrado) {
        if (!devicekey) return { semChave: true };
        return decifrar(devicekey, m.bruto, m.iv);
    }
    return JSON.parse(m.bruto);
}

function postar(host, porta, caminho, corpo, ms) {
    return new Promise((resolve, reject) => {
        const texto = JSON.stringify(corpo);
        const req = http.request({
            host,
            port: porta,
            path: caminho,
            method: 'POST',
            agent: false,
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(texto),
                Connection: 'close'
            },
            timeout: ms || 5000
        }, (res) => {
            const partes = [];
            res.on('data', (p) => partes.push(p));
            res.on('end', () => {
                try {
                    resolve(JSON.parse(Buffer.concat(partes).toString('utf8') || '{}'));
                } catch (e) {
                    reject(new Error('resposta invalida'));
                }
            });
        });
        req.on('timeout', () => req.destroy(new Error('tempo esgotado')));
        req.on('error', reject);
        req.end(texto);
    });
}

async function enviarLocal(disp, comando, dados, ms) {
    const corpo = {
        sequence: String(Date.now()),
        deviceid: disp.id,
        selfApikey: '123',
        data: dados || {}
    };
    if (disp.chave) {
        const c = cifrar(disp.chave, corpo.data);
        corpo.encrypt = true;
        corpo.iv = c.iv;
        corpo.data = c.data;
    }
    let ultimo;
    for (let i = 0; i < 10; i++) {
        try {
            const r = await postar(disp.ip, disp.porta || 8081, '/zeroconf/' + comando, corpo, ms);
            let dado = r.data;
            if (r.iv && typeof dado === 'string' && disp.chave) dado = decifrar(disp.chave, dado, r.iv);
            else if (typeof dado === 'string' && dado) dado = JSON.parse(dado);
            return { erro: r.error === undefined ? 0 : r.error, dados: dado || {} };
        } catch (e) {
            ultimo = e;
            if (!/ECONNRESET|ECONNREFUSED/.test(e.code || '')) break;
            await new Promise((ok) => setTimeout(ok, 100));
        }
    }
    throw ultimo;
}

function assinar(segredo, texto) {
    return crypto.createHmac('sha256', segredo).update(texto).digest('base64');
}

async function pedir(regiao, caminho, opcoes) {
    const url = API[regiao] + caminho;
    const r = await fetch(url, opcoes);
    return r.json();
}

const APP_PADRAO = 'R8Oq3y0eSZSYdKccHlrQzT1ACCOUT9Gv';
const SEGREDO_PADRAO = '1ve5Qk9GXfUhKAn1svnKwpAlxXkMarru';

async function entrar(entrada) {
    const cfg = Object.assign({}, entrada, { appid: APP_PADRAO, segredo: SEGREDO_PADRAO });
    let regiao = 'us';
    const corpo = { password: cfg.senha, countryCode: cfg.pais || '+55' };
    if (cfg.usuario.indexOf('@') >= 0) corpo.email = cfg.usuario;
    else corpo.phoneNumber = cfg.usuario.charAt(0) === '+' ? cfg.usuario : '+' + cfg.usuario;
    const texto = JSON.stringify(corpo);
    for (let t = 0; t < 2; t++) {
        const resp = await pedir(regiao, '/v2/user/login', {
            method: 'POST',
            headers: {
                Authorization: 'Sign ' + assinar(cfg.segredo, texto),
                'Content-Type': 'application/json',
                'X-CK-Appid': cfg.appid,
                'X-CK-Nonce': crypto.randomBytes(4).toString('hex')
            },
            body: texto
        });
        if (resp.error === 10004 && resp.data && resp.data.region) {
            regiao = resp.data.region;
            continue;
        }
        if (resp.error) throw new Error('login ' + resp.error + (resp.msg ? ' ' + resp.msg : ''));
        return { regiao, token: resp.data.at, apikey: resp.data.user && resp.data.user.apikey };
    }
    throw new Error('login: regiao nao resolvida');
}

function erroNuvem(rotulo, resp) {
    const e = new Error(rotulo + ' ' + resp.error + (resp.msg ? ' ' + resp.msg : ''));
    e.codigo = resp.error;
    return e;
}

async function enviarNuvem(sessao, disp, params) {
    const r = await pedir(sessao.regiao, '/v2/device/thing/status', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + sessao.token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 1, id: disp.id, params })
    });
    if (r.error) throw erroNuvem('comando', r);
    return r;
}

class ClienteNuvem extends EventEmitter {
    constructor(sessao, appid) {
        super();
        this.sessao = sessao;
        this.appid = appid;
        this.ws = null;
        this.ping = null;
        this.parado = false;
        this.falhas = 0;
        this.espera = null;
    }

    iniciar() {
        this.parado = false;
        this.conectar();
    }

    parar() {
        this.parado = true;
        clearTimeout(this.espera);
        this.limpar();
        if (this.ws) {
            try {
                this.ws.terminate();
            } catch (e) {
                this.ws = null;
            }
        }
        this.ws = null;
    }

    limpar() {
        clearInterval(this.ping);
        this.ping = null;
    }

    reagendar() {
        if (this.parado) return;
        this.falhas += 1;
        const atraso = 15000 * Math.pow(2, Math.min(this.falhas - 1, 6));
        this.emit('caiu', atraso);
        this.espera = setTimeout(() => this.conectar(), atraso);
    }

    async conectar() {
        if (this.parado) return;
        let aberto = false;
        try {
            const r = await fetch(DISPATCH[this.sessao.regiao], { headers: { Authorization: 'Bearer ' + this.sessao.token } });
            const resp = await r.json();
            if (!resp.domain) throw new Error('dispatch ' + (resp.error || ''));
            const ws = new WebSocket(ajustes.esquemaWs + '://' + resp.domain + ':' + resp.port + '/api/ws');
            this.ws = ws;
            ws.on('open', () => {
                const ts = Date.now() / 1000;
                ws.send(JSON.stringify({
                    action: 'userOnline',
                    at: this.sessao.token,
                    apikey: this.sessao.apikey,
                    appid: this.appid,
                    nonce: String(Math.floor(ts / 100)),
                    ts: Math.floor(ts),
                    userAgent: 'app',
                    sequence: String(Math.floor(ts * 1000)),
                    version: 8
                }));
            });
            ws.on('message', (bruto) => {
                const texto = bruto.toString();
                if (texto === 'pong') return;
                let msg;
                try {
                    msg = JSON.parse(texto);
                } catch (e) {
                    return;
                }
                if (!aberto) {
                    if (msg.error) {
                        this.emit('erro', msg.error === 406 ? 'login em outro lugar (406)' : 'erro ' + msg.error);
                        ws.terminate();
                        return;
                    }
                    aberto = true;
                    this.falhas = 0;
                    const hb = msg.config && msg.config.hb ? Number(msg.config.hbInterval) : 0;
                    if (hb) this.ping = setInterval(() => ws.readyState === 1 && ws.send('ping'), hb * 1000);
                    this.emit('conectado');
                    return;
                }
                this.processar(msg);
            });
            ws.on('close', () => {
                this.limpar();
                if (this.ws === ws) this.ws = null;
                this.reagendar();
            });
            ws.on('error', (e) => {
                this.emit('erro', e.message);
            });
        } catch (e) {
            this.emit('erro', e.message);
            this.reagendar();
        }
    }

    processar(msg) {
        if (msg.action === 'sysmsg' && msg.deviceid && msg.params && typeof msg.params.online === 'boolean') {
            this.emit('online', msg.deviceid, msg.params.online);
            return;
        }
        if (msg.deviceid && msg.params && typeof msg.params === 'object' && (msg.action === 'update' || !msg.action)) {
            this.emit('update', msg.deviceid, msg.params);
        }
    }

    consultar(disp) {
        if (!this.ws || this.ws.readyState !== 1) return false;
        this.ws.send(JSON.stringify({
            action: 'query',
            apikey: disp.apikey,
            selfApikey: this.sessao.apikey,
            deviceid: disp.id,
            params: [],
            userAgent: 'app',
            sequence: String(Date.now())
        }));
        return true;
    }

    get conectado() {
        return !!this.ws && this.ws.readyState === 1;
    }
}

async function listarNuvem(sessao) {
    const cab = { Authorization: 'Bearer ' + sessao.token };
    const casas = await pedir(sessao.regiao, '/v2/family', { headers: cab });
    if (casas.error) throw erroNuvem('familias', casas);
    const mapa = {};
    const lista = (casas.data && casas.data.familyList) || [];
    const consultas = lista.length ? lista.map((c) => ({ id: c.id, nome: c.name })) : [{ id: '', nome: '' }];
    for (const casa of consultas) {
        const q = '?num=0' + (casa.id ? '&familyid=' + encodeURIComponent(casa.id) : '');
        const r = await pedir(sessao.regiao, '/v2/device/thing' + q, { headers: cab });
        if (r.error) throw erroNuvem('dispositivos', r);
        for (const item of (r.data && r.data.thingList) || []) {
            const d = item.itemData;
            if (!d || !d.deviceid) continue;
            mapa[d.deviceid] = {
                id: d.deviceid,
                nome: d.name || d.deviceid,
                casa: casa.nome,
                chave: d.devicekey || '',
                modelo: d.productModel || '',
                uiid: d.extra && d.extra.uiid,
                apikey: d.apikey || '',
                online: d.online === true,
                params: d.params || {}
            };
        }
    }
    return Object.keys(mapa).map((k) => mapa[k]);
}

function achatar(params) {
    const saida = {};
    for (const k of Object.keys(params || {})) {
        const v = params[k];
        if (k === 'switches' && Array.isArray(v)) {
            for (const s of v) saida['switch_' + s.outlet] = s.switch === 'on';
        } else if (k === 'switch') {
            saida.switch = v === 'on';
        } else if (v !== null && typeof v === 'object') {
            saida[k] = JSON.stringify(v);
        } else {
            saida[k] = v;
        }
    }
    return saida;
}

function montarComando(codigo, valor) {
    const lig = (v) => (v === true || v === 'on' || v === 'ON' || v === 'true' || v === 1 ? 'on' : 'off');
    const m = /^switch_(\d+)$/.exec(codigo);
    if (m) return { comando: 'switches', dados: { switches: [{ switch: lig(valor), outlet: Number(m[1]) }] } };
    if (codigo === 'switch') return { comando: 'switch', dados: { switch: lig(valor) } };
    return { comando: codigo, dados: { [codigo]: valor } };
}

module.exports = {
    cifrar,
    decifrar,
    lerTxt,
    interpretarTxt,
    enviarLocal,
    entrar,
    listarNuvem,
    enviarNuvem,
    ClienteNuvem,
    appId: () => APP_PADRAO,
    API,
    DISPATCH,
    ajustes,
    achatar,
    montarComando
};
